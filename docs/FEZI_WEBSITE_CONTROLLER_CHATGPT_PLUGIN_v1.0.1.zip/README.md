# FEZI Website Controller v1.0.0

A private ChatGPT plugin for website editing workflows with a companion patch for the self-hosted FEZI Studio Node.js 22 site.

- ChatGPT Sites (`sites-project://`): editor handoff when no official site-writing interface is exposed; no fake automatic access.
- FEZI Studio: authenticated MCP read, preview, confirm-and-apply exact text changes with checkpoint, no shell.
- GitHub: repository branch/PR workflow when authorized connector access exists.

See docs/INSTALL_FA.md for exact deployment notes.
