---
name: fezi-chatgpt-sites-handoff
description: Use for ChatGPT-hosted sites-project:// URLs when no directly authorized Sites write tool is exposed. Provide exact actionable editor handoff instead of claiming edits happened.
---

# ChatGPT Sites project handoff

- Recognize `sites-project://appgprj_...` as a Sites project identifier, not an automatically callable service.
- Do not invent a Sites API or claim the plugin can read/change the project through this URI alone.
- If the current environment actually exposes a Sites edit tool, use its documented contract and confirm result.
- Otherwise output a complete change request addressed to the named Sites project, for example:

`[FEZI Studio](sites-project://appgprj_...) make these changes… <exact requirements; do not alter other pages; preserve sources; test before publish>`

- Include the expected visual result, functionality, language behavior and testing requirements.
- If source export or GitHub mirror is available, patch that source with authorized tools, but clarify it does **not** update the original ChatGPT Sites project until imported or synced.
