---
name: fezi-studio-mcp-editor
description: Use to read and safely edit text files in a deployed FEZI Studio Node.js 22 project using owner-authenticated MCP read-preview-confirm-apply workflow.
---

# FEZI Studio remote MCP editor

## Preconditions
- Site uses FEZI Studio Node.js backend with `fezi-site-editor.mjs` companion patch installed.
- HTTPS domain available; private MCP has secure integration/OAuth gateway or an explicitly supported owner-authentication mechanism. Never paste bearer token into chat.
- The user authorizes file editing of a project they control.

## Supported tools
1. `fezi_remote_status`: runtime configuration status, not external service guarantee.
2. `fezi_remote_projects`: list FEZI Studio projects and project IDs.
3. `fezi_site_read({projectId,path?})`: list/read project text files with SHA-256.
4. `fezi_site_preview_replace({projectId,path,find,replace})`: preview exact unique replacement; returns expectedSha256; does not save.
5. `fezi_site_apply_replace({projectId,path,find,replace,expectedSha256,confirm:true})`: after explicit user approval, creates checkpoint, verifies original SHA-256, and saves.
6. `fezi_remote_jobs`, `fezi_remote_start_agent`, `fezi_remote_checkpoint`: optional agent planning and checkpoints.

## Behavior
- Read and preview first. Explain the proposed change and get approval for applying.
- Change one uniquely matching text span at a time. Multi-file edits should be sequenced after previews and tested.
- Reject path traversal and any attempt to access credentials or arbitrary server shell.
- `saved_to_fezi_studio` is **not** the same as production deployment. Use separate authorized deployment steps and verify real URL.
- If stale SHA or missing file, refresh and review instead of retrying blindly.
