---
name: fezi-github-site-changes
description: Use to update a website source in an authorized GitHub repository with a safe branch and pull request, when GitHub account and write permissions are actually connected.
---

# GitHub-managed website edit

- Determine the exact owner/repository/branch. `feziai/FEZI-STUDIO` is a known repository name but not proof that FEZI Studio source has been uploaded.
- Verify current files, linked site and commit SHA before writing.
- Do not create commits to main or force push without user-approved workflow; prefer feature branches and pull requests.
- Preserve `.gitignore`, prevent `.env`/tokens and data uploads, and run relevant tests.
- If GitHub reports 403, do not use leaked user tokens from any archived `.txt` as a workaround. Request supported connection permissions.
- Report separately: prepared, committed, merged, deployed, verified.
