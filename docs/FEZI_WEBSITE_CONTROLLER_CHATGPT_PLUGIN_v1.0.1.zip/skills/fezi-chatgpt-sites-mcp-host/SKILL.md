---
name: fezi-chatgpt-sites-mcp-host
description: Use for the official ChatGPT Sites workflow when the owner wants their Site to expose MCP tools through a ChatGPT plugin, or wants to edit site source from ChatGPT.
---

# Native ChatGPT Sites + plugin setup

## Editing original Site code
- Open the creation chat or Sites sidebar on **ChatGPT web or desktop** and select the Site's edit control.
- Describe code/design edits, inspect preview, and publish the new version **only after review**.
- If the published Site offers an Edit Site control, use it to send edits back into ChatGPT Sites.
- A `sites-project://` link does not give an unrelated plugin arbitrary source-write access. Do not claim the plugin edited a Site unless the supported Sites editor operation really happened.

## Hosting MCP tools on an existing Site
- Ask ChatGPT or Codex to add a small, scoped MCP server **to the existing Site** that exports only the workflow actions the owner wants (e.g. list projects, inspect published configuration, request a safe edit, update authorized app data).
- Test tools on sample data, and have the owner **publish** the Site after adding tools.
- Review the resulting plugin card, install and connect it. The owner may need separate authorization for connected services.
- Source code editing through Sites remains the Sites editing flow. The MCP server's tools can update only the app data/actions that the Site explicitly exposes; they are not a universal source editor.

## References
- https://help.openai.com/en/articles/20001339-creating-and-using-chatgpt-sites
- https://help.openai.com/en/articles/20001547-hosting-a-plugin-with-chatgpt-sites
