---
name: fezi-website-qa-and-rollback
description: Use after a FEZI Studio website change to verify rendering, routing, backend functionality, security, content preservation and rollback readiness.
---

# Verify website edits

- After editing, run available Node.js unit tests and route smoke tests in a temporary/staging environment.
- Check requested visual changes on desktop/mobile and RTL/LTR as relevant. Don't claim screenshot verification if not rendered.
- Ensure Rabbit-F logo assets, landing page routes, AI chat, Plugin Hub, Telegram and FeziPay remain intact unless intentionally changed.
- Check unauthorized attempts fail and any real secrets remain server-side.
- Use the checkpoint created before writes; rollback only via a separately authorized and verified restore path. Checkpoint creation alone is not proof of working rollback.
- Record exact file path, before/after hash, test outcome, deployment target, and actual verification URL.
